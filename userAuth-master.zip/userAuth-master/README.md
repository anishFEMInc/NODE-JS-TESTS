userAuth
========

User Authentication with express, passport, and orchestrate. Read the blog post [here] (https://orchestrate.io/blog/2014/06/26/build-user-authentication-with-node-js-express-passport-and-orchestrate/).
